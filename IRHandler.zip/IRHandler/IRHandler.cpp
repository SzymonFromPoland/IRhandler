#include "IRHandler.h"

IRHandler::IRHandler(int irPin, int ledPin, unsigned long programAddress, unsigned long eventAddress)
  : IR_PIN(irPin), LED(ledPin), PROGRAM_ADDRESS(programAddress), EVENT_ADDRESS(eventAddress), rc5(irPin) {}

void IRHandler::begin() {
  pinMode(LED, OUTPUT);
  esp_task_wdt_deinit();

  xTaskCreatePinnedToCore(
    handleIR,   // Static function
    "handleIR",
    10000,
    this,       // Pass the instance
    1,
    &Task1,
    0);
}

int IRHandler::checkStatus() {
  if (statusChanged) {
    statusChanged = false;  // Reset the flag after reading status
    return status;
  }
  return -1;  // Return -1 if no status change
}

void IRHandler::handleIR(void* parameter) {
  IRHandler* instance = static_cast<IRHandler*>(parameter);

  for (;;) {
    if (instance->rc5.read(&instance->toggle, &instance->address, &instance->command)) {
      if (!instance->PROGRAMMED) {
        if (instance->address == instance->PROGRAM_ADDRESS) {
          instance->PROGRAMMED = true;
          instance->STOP = instance->command;
          instance->START = instance->command + 1;
          instance->status = 1;
          instance->statusChanged = true;  // Set the flag to true
          digitalWrite(instance->LED, HIGH);
          delay(500);
          digitalWrite(instance->LED, LOW);
          delay(500);
          digitalWrite(instance->LED, HIGH);
          delay(500);
          digitalWrite(instance->LED, LOW);
          delay(500);
        }
      }

      if (instance->address == instance->EVENT_ADDRESS) {
        if (instance->command == instance->STOP) {
          instance->status = 3;
          instance->statusChanged = true;  // Set the flag to true
          digitalWrite(instance->LED, LOW);
        }
        if (instance->command == instance->START) {
          instance->status = 2;
          instance->statusChanged = true;  // Set the flag to true
          digitalWrite(instance->LED, HIGH);
        }
      }
      vTaskDelay(10);
    }
  }
}
