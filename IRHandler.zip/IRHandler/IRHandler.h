#ifndef IRHandler_h
#define IRHandler_h

#include <Arduino.h>
#include <RC5.h>
#include <esp_task_wdt.h>

class IRHandler {
public:
  IRHandler(int irPin, int ledPin, unsigned long programAddress, unsigned long eventAddress);
  void begin();
  int checkStatus();
  
  static void handleIR(void* parameter);  // Make this static
  
private:
  int IR_PIN;
  int LED;
  unsigned long PROGRAM_ADDRESS;
  unsigned long EVENT_ADDRESS;
  RC5 rc5;  // Assuming you are using an RC5 IR library
  
  bool PROGRAMMED = false;
  unsigned long STOP = 0;
  unsigned long START = 0;
  int status = 0;
  
  bool statusChanged = false;  // Flag to indicate if the status changed
  unsigned char toggle;  // Change to unsigned char
  unsigned char address; // Change to unsigned char
  unsigned char command; // Change to unsigned char
  
  TaskHandle_t Task1;
};


#endif
